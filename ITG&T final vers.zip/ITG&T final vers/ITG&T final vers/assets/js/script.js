const wrapper = document.querySelector(".wrapper"),
    searchInput = wrapper.querySelector("input"),
    volume = wrapper.querySelector(".word i"),
    infoText = wrapper.querySelector(".info-text"),
    removeIcon = wrapper.querySelector(".search span");

  




const dictionaryData = {
    'algorithm': {
      'definition': 'A set of instructions that a computer follows to complete a task.',
      'example': 'The algorithm for finding the largest number in a list is to compare each number in the list to the largest number found so far, and then replace the largest number found so far with the new number if it is larger.'
    },
    'application': {
      'definition': 'A software program that performs a specific task, such as a word processor, web browser, or game.',
      'example': 'Microsoft Word is an application that is used to create and edit documents.'
    },
    'artificial intelligence (AI)': {
      'definition': 'The ability of a machine to simulate human intelligence, such as the ability to learn, reason, and make decisions.',
      'example': 'Self-driving cars use AI to navigate roads and avoid obstacles.'
    },
    'bandwidth': {
      'definition': 'The amount of data that can be transmitted over a network connection in a given period of time.',
      'example': 'A high-bandwidth internet connection is required for streaming video and playing online games.'
    },
    'bug': {
      'definition': 'An error in a software program that causes it to malfunction.',
      'example': 'A bug in a web browser might cause it to crash when visiting a certain website.'
    },
    'cache': {
      'definition': 'A temporary storage area for data that is frequently accessed.',
      'example': 'A web browser cache stores copies of recently visited web pages so that they can be loaded more quickly the next time they are visited.'
    },
    'cloud computing': {
      'definition': 'The delivery of computing services over the internet, such as storage, processing, and software.',
      'example': 'Google Drive is a cloud computing service that provides online storage for files.'
    },
    'compiler': {
      'definition': 'A software program that translates a programming language into machine code that can be executed by a computer.',
      'example': 'The GCC compiler is used to compile C and C++ programs.'
    },
    'cookie': {
      'definition': 'A small piece of data that is stored on a user\'s computer by a website.',
      'example': 'A cookie can be used to track a user\'s browsing history or to keep them logged in to a website.'
    },
    'database': {
      'definition': 'A collection of organized data that can be easily accessed and manipulated.',
      'example': 'A database can be used to store customer information, product data, or financial records.'
    },
    'debug': {
      'definition': 'The process of finding and fixing bugs in a software program.',
      'example': 'A programmer might debug a software program by adding print statements to the code to see what values are being stored in different variables.'
    },
    'desktop computer': {
      'definition': 'A personal computer that is designed to be used on a desk.',
      'example': 'A desktop computer typically consists of a monitor, keyboard, mouse, and CPU.'
    },
    'digital camera': {
      'definition': 'A device that takes digital photographs, which are stored electronically instead of on film.',
      'example': 'A digital camera can be used to take photos for personal use or for professional photography.'
    },
    'domain name': {
      'definition': 'The unique name that identifies a website on the internet.',
      'example': 'The domain name for Google is www.google.com.'
    },
    'driver': {
      'definition': 'A software program that allows a computer to communicate with a hardware device.',
      'example': 'A printer driver allows a computer to communicate with a printer.'
    },
    'dmail': {
      'definition': 'A system for sending and receiving electronic messages.',
      'example': 'Email can be used to send text messages, images, and other files.'
    },
    'encryption': {
      'definition': 'The process of converting data into a format that cannot be read by unauthorized individuals.',
      'example': 'Encryption is used to protect sensitive data, such as credit card numbers and passwords.'
    },
    'firewall': {
      'definition': 'A network security device that monitors and controls incoming and outgoing network traffic.',
      'example': 'A firewall can be used to protect a computer or network from unauthorized access.'
    },
    'firmware': {
      'definition': 'Software that is built into a hardware device and controls its operation.',
      'example': 'The firmware for a router controls how it routes network traffic.'
    },
    'free software': {
      'definition': 'Software that is freely available to use, copy, and modify.',
      'example': 'The Linux operating system is an example of free software.'
    },
    'virtualization': {
      'definition': 'The process of creating a virtual (rather than actual) version of IT resources like an operating system, a server, a storage device, or a network.',
      'example': 'VMware allows the creation of multiple virtual machines on a single physical machine.' 
    },
    'blockchain': {
      'definition': 'A decentralized and distributed digital ledger technology that records transactions across multiple computers securely.',
      'example': 'Cryptocurrencies like Bitcoin use blockchain to record and secure transactions.'
    }, 
     'open Source': {
      'definition': 'Software with its source code made available for modification and enhancement by anyone, fostering collaboration and innovation.',
      'example': 'Linux, an open-source operating system, allows users to access and modify its source code.'
    },
    'IoT': {
      'definition': 'Internet of Things. A network of interconnected devices that can communicate and share data, enabling automation and advanced connectivity.',
      'example': 'Smart home devices like thermostats, lights, and security cameras form an IoT ecosystem.'
    },
    'LAN ': {
      'definition': 'Local Area Network. A network that connects computers and devices within a limited geographical area, such as a home, office, or school.',
      'example': 'Ethernet or Wi-Fi connections in an office that link computers and printers constitute a LAN.'
    },
    'WAN': {
      'definition': 'Wide Area Network. A network that covers a broad area, connecting devices in multiple locations. The internet is the largest WAN.',
      'example': 'Connecting branch offices of a company across different cities via a network is an example of a WAN.'
    },
    'VPN': {
      'definition': 'Virtual Private Network. A secure and encrypted connection that enables users to access a private network over a public network, such as the internet.',
      'example': 'Using a VPN to access a companys intranet securely while working remotely from a coffee shop.'
    },
    'agile methodology': {
      'definition': 'A project management approach that emphasizes flexibility, collaboration, and iterative development to respond to changes and deliver value quickly.',
      'example': 'Software development teams use Agile methodologies like Scrum or Kanban for faster and adaptable project completion.'
    },
    'SDLC': {
      'definition': 'Software Development Life Cycle. The process of developing software through a series of well-defined phases, including planning, design, development, testing, and maintenance.',
      'example': 'The stages of software creation, from requirement analysis to software deployment, follow the SDLC.'
    },
    'HTML': {
      'definition': 'Hypertext Markup Language. The standard language used to create web pages. It defines the structure and layout of a web document by using a variety of tags and attributes.',
      'example': 'HTML tags like <head>, <body>, and <h1> are used to structure and present content on web pages.'
    },
    'CSS': {
      'definition': 'Cascading Style Sheets. A style sheet language used for describing the presentation of a document written in HTML. It defines how elements are displayed on the screen, paper, or other media.',
      'example': 'Using CSS, you can specify colors, fonts, margins, and layout of a web page.'
    },
    'JavaScript': {
      'definition': 'A programming language that enables interactive elements and dynamic content on web pages. It is primarily used for client-side scripting.',
      'example': 'JavaScript is used for functions like form validation, interactive maps, and dynamic page content.'
    },
    'big data': {
      'definition': 'Large and complex datasets that are challenging to manage and process using traditional database management tools.',
      'example': 'Analyzing large volumes of social media data to derive insights is an example of working with big data.'
    },
    'cybersecurity': {
      'definition': 'The practice of protecting systems, networks, and data from digital attacks, unauthorized access, and cyber threats.',
      'example': 'Using firewalls, encryption, and multi-factor authentication are essential components of cybersecurity.'
    },
     'rootkit': {
      'definition': 'Malicious software designed to gain unauthorized access to a computer system, often concealing its presence or controlling system functions.',
      'example': 'A rootkit may enable an attacker to access sensitive information or control a compromised system.'
    },
    'malware': {
      'definition': 'A collective term for various types of malicious software, including viruses, worms, trojans, ransomware, and spyware.',
      'example': 'Ransomware encrypts files on a users computer and demands payment for their release.'
    },
    'data breach': {
      'definition': 'The unauthorized access, exposure, or acquisition of sensitive or confidential information, often leading to privacy and security risks.',
      'example': 'A cyberattack on a companys database resulting in leaked customer information constitutes a data breach.'
    },
    'phishing': {
      'definition': 'A fraudulent attempt to obtain sensitive information by posing as a trustworthy entity in electronic communication, typically through email.',
      'example': 'An email impersonating a bank and asking for account details is a common phishing tactic.'
    },
    'metadata': {
      'definition': 'Data that provides information about other data, describing details such as content, structure, and context for understanding it.',
      'example': 'Metadata in a digital photo file includes details like the date, location, and camera settings.'
    },
    'data mining': {
      'definition': 'The process of analyzing large datasets to identify patterns, anomalies, and relationships, often used to extract valuable information.',
      'example': 'Retailers use data mining to analyze customer purchase patterns for targeted marketing campaigns.'
    },
    'cyberattack': {
      'definition': 'Deliberate exploitation of computer systems, networks, or technologies, often involving unauthorized access or damage to disrupt operations.',
      'example': 'A Distributed Denial of Service (DDoS) attack flooding a website with traffic to make it inaccessible.'
    },
    'dark web': {
      'definition': 'A part of the internet that requires special software to access, often associated with illegal activities, marketplaces, and anonymity.',
      'example': 'The dark web includes sites not indexed by traditional search engines, accessed using tools like Tor.'
    },
    'biometrics': {
      'definition': 'Identification or authentication of individuals based on unique physical characteristics such as fingerprints, facial features, or iris patterns.',
      'example': 'Smartphones using fingerprint or facial recognition to unlock the device use biometric authentication.'
    },
};
  
  


  searchInput.addEventListener("keyup", e => {
    let query = e.target.value.trim(); 

    if (e.key === "Enter" && query) {
        query = query.toLowerCase(); 

        let foundWord = null;

        
        for (const word in dictionaryData) {
            if (word.toLowerCase() === query) {
                foundWord = word;
                break;
            }
        }

        if (foundWord) {
            
            document.querySelector(".word p").innerText = foundWord;
            document.querySelector(".meaning span").innerText = dictionaryData[foundWord].definition;
            document.querySelector(".example span").innerText = dictionaryData[foundWord].example;
            wrapper.classList.add("active");
            infoText.style.color = "#4D59FB";
            infoText.innerHTML = "Definition and example for the word:";
        } else {
            
            wrapper.classList.remove("active");
            infoText.style.color = "#FF0000";
            infoText.innerHTML = "Word not found in the dictionary.";
        }
    }
});


